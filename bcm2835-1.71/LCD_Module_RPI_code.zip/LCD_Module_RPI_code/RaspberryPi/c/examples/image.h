#ifndef _IMAGE_H_
#define _IMAGE_H_

extern const unsigned char gImage_1[];
extern const unsigned char gImage_70X70[];

#endif
